# Рабочая среда, запуск и безопасное продолжение

**8 сентября — [Nightwatch R1](../Changes/NIGHTWATCH_R1_2026-09-08.md):** runtime использует `/Game/Characters/CrewNightwatchR5`, обе актуальные карты оформлены в сумраке. Для просмотра: `./Scripts/start_game.ps1 -Mode Solo -MapName OceanFreighterR7 -StartPaused`. Скрипты `apply_nightwatch_r1.py`, `refine_nightwatch_r1.py` и `fix_nightwatch_light_overlap.py` — защищённые одноразовые миграции, не запускать поверх следующих изменений. Blender CLI / Unreal Python использованы без установки новых MCP, программ, изменения firewall или RTX.

Проверено 2026-09-06. Репозиторий: `E:\Game\CalmyPiratesCoUE`. Unity-источник `E:\Game\CalmyPiratesCo` не переносится и не меняется этим аудитом.

## Среда

8 сентября добавлен собственный навык `calmy-dream-loop` в `C:/Users/Valerii/.codex/skills/calmy-dream-loop/SKILL.md`; validator PASS. [Проектный цикл и границы](../Changes/ENGINE_DREAM_LOOP_R1_2026-09-08.md). Unreal и Blender доступны через CLI; Blender MCP в background режиме не обслуживает команды, поэтому read-only raycast выполнялся напрямую Python API Blender, не через MCP.

| Компонент | Проверенный источник / назначение |
|---|---|
| UE 5.8.2 | `E:\Games\UE_5.8`, сохранённые build/test logs; .uproject привязан к семейству 5.8 |
| Blender 5.2.1 LTS | `E:\Tools\blender-5.2.1-windows-x64\blender.exe`, авторинг R7 |
| Visual Studio / SDK | Community 2026; последние сборки MSVC 14.50, SDK 10.0.22621.0; [.vsconfig](../../.vsconfig) |
| Unreal MCP | Editor-only ModelContextProtocol/AllToolsets, `http://127.0.0.1:8000/mcp` |
| Blender MCP | [.codex/config.toml](../../.codex/config.toml): uvx, pin `blender-mcp==1.9.0`, loopback 9876, telemetry disabled |
| Renderer | DX12 / SM6, Lumen, Virtual Shadow Maps; [DefaultEngine.ini](../../Config/DefaultEngine.ini) |
| Runtime modules | EnhancedInput, GameplayAbilities/Tags/Tasks, AIModule, ProceduralMeshComponent; наличие модуля не означает готовность всех систем GAS |

PythonScriptPlugin, EditorScriptingUtilities и MCP разрешены только Editor target. В игровых запусках отключается editor Python startup. Наличие конфигурации не равно живому соединению: в момент прежнего документационного аудита TCP 9876 слушался на loopback, 8000 — нет. Это исторический снимок, не постоянная гарантия MCP. В R3 использованы Blender CLI и Unreal Python/Editor/game; новые инструменты не устанавливались, публичные соединения не открывались.

R3 авторинг/импорт: [create_crew_cargo_r3.py](../../Scripts/create_crew_cargo_r3.py) и [import_crew_cargo_r3.py](../../Scripts/import_crew_cargo_r3.py). Генератор защищает существующий master от перезаписи. Исходная WaterLab сохранена в `SourceAssets/Backups/Before-CrewCargoR3-20260906/WaterLab.umap`; импорт меняет только новую графику, реакцию воды и размещённого NPC/табличку на WaterLab. Выход редактора после импорта отложен на 12 секунд: немедленный quit вызвал teardown ensure в первом запуске; исправленный повтор завершился штатно. Не повторять импорт поверх несохранённой пользовательской сцены.

Aura, альтернативный UE MCP, MetaHuman/AccuRIG/Cascadeur/Meshy не входят в подтверждённый текущий pipeline; этот документ не утверждает, что провёл полную инвентаризацию программ Windows. Старый документ стека из Downloads — planning reference, не команда на установку и не перечень уже установленного.

## Играть из текущих исходников

```powershell
Set-Location E:\Game\CalmyPiratesCoUE
& ./Scripts/start_game.ps1 -Mode Solo
# Открыть игру сразу на паузе:
& ./Scripts/start_game.ps1 -Mode Solo -StartPaused
# Свежий R7, отдельная статическая карта с персонажем LP4:
& ./Scripts/start_game.ps1 -Mode Solo -MapName OceanFreighterR7 -StartPaused
# Для проверки двумя отдельными окнами на этом ПК:
& ./Scripts/start_game.ps1 -Mode Host -Port 17777
& ./Scripts/start_game.ps1 -Mode Client -Port 17777
```

Это Editor executable в режиме game, **не** обновлённый Windows-Current. [Управление](GAMEPLAY.md). `-MapName` поддерживает WaterLab (по умолчанию), OceanFreighterR7, FreighterDeck, ShiftTest, CargoLab, LeakTest. DeckTest доступен напрямую через редактор/старый Carry smoke, но не в ValidateSet этого launcher. R7 пока неподвижен; посадка обратно из воды и полный рейс не реализованы. [Отчёт интеграции](../Changes/SHIP_R7_INTEGRATION_2026-09-06.md).

## Открыть авторинг

```powershell
& ./Scripts/start_dev.ps1
& ./Scripts/Open-OceanFreighter.ps1
```

`start_dev` открывает редактор проекта и Blender при необходимости, проверяет порты; `Open-OceanFreighter` открывает конкретный master с панелью Ship Review. Не запускать второй master поверх несохранённой работы вслепую. Сначала сохранить/проверить dirty state. Blender background export не поддерживает интерактивный MCP — это не повод переустанавливать инструменты.

## Собрать Editor

Закрыть свой редактор штатно; убедиться, что тестовые процессы завершились и не держат DLL. Не завершать чужие/пользовательские процессы без проверки.

```powershell
& 'E:\Games\UE_5.8\Engine\Build\BatchFiles\Build.bat' CalmyPiratesCoEditor Win64 Development '-Project=E:\Game\CalmyPiratesCoUE\CalmyPiratesCo.uproject' -WaitMutex -NoHotReloadFromIDE -gather
```

`-gather` важен после добавления новых исходников/тестов. Сборка сама по себе не является gameplay PASS. Затем выполнить [проверки](VALIDATION.md).

## Пакет — незакрытый риск

Последний найденный timestamp-пакет: `Builds/Windows-20260904-183719`; Current тоже от 4 сентября. [package_windows.ps1](../../Scripts/package_windows.ps1) собирает Development, затем автоматически заменяет Windows-Current и после успеха удаляет previous. **Это ещё не двухэтапный candidate → smoke → promote pipeline.** Не выдавать PACKAGE_CURRENT_PASS за игровую приёмку.

Следующая P0-работа — разделить упаковку и продвижение, сохранить принятый пакет, проверить новый candidate без редактора, только потом обновить Current. В этом аудите скрипт упаковки и сам пакет не изменялись. Старые команды из History могут продвигать пакет или перегенерировать модель; не выполнять их как стандартный setup.

## Сохранность

Evidence — локальные замороженные доказательства, не независимый off-device backup. Source/Content в Git ещё не имеют подтверждённой коммитной истории; массовые untracked-файлы не разрешают удаление. [AGENTS](../../AGENTS.md) не изменён. Не трогать firewall/публичные порты, не покупать ассеты, не менять движок, не коммитить/push без соответствующей задачи.

Публикационные `publish_ocean_r6.py`, `publish_ocean_cargo_r7.py` и архиватор R2 — одноразовые операции с защитами. Повторный отказ «archive exists» нормален; не обходить защиту. Новые модели, рендеры и результаты — отдельные кандидаты и имена. Полная воспроизводимость генератора с нуля остаётся задачей, не обещанием setup.
