# ASSET_PROVENANCE

Документ упорядочен 2026-09-06; этот путь сохранён для совместимости.

- [Актуальная информация](Docs/Current/ASSETS.md)
- [Исходный отчёт — история, не текущая приёмка](Docs/History/ASSET_PROVENANCE.md)
- [Все документы проекта](Docs/INDEX.md)
