# Repository rules

- Public title: **Calmy Pirates Co.**
- Engine baseline: Unreal Engine `5.8.2` until an approved migration is recorded.
- This is a modern coastal-freighter co-op comedy, not a fantasy pirate game.
- Host/server owns gameplay outcomes; clients submit validated intent and own input, camera, and cosmetic feedback.
- Preserve explicit state machines: carryable `Free -> Reserved -> Held -> Thrown -> Free`; player `Controlled -> KnockedDown -> Recovering -> Controlled`.
- Every RPC must document caller, receiver, validation, duplicate behavior, late join, and disconnect behavior.
- Greybox and measurable play value come before bulk asset import or presentation polish.
- Do not expose Unreal MCP outside loopback or change Windows Firewall rules.
- Do not hand-edit `.uasset` or `.umap` binary files.
- Do not claim a human fun gate passed without the required human players.
- Never push, merge, rewrite history, delete project roots, or enable bypass permissions autonomously.
- A gameplay change is incomplete without relevant automation tests and Host/Client evidence.
